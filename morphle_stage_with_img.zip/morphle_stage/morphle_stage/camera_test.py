#!/usr/bin/env python3

import rclpy
from rclpy.node import Node

from sensor_msgs.msg import Image
from cv_bridge import CvBridge

import cv2
import time


class CameraTest(Node):

    def __init__(self):
        super().__init__('camera_test')

        self.bridge = CvBridge()

        self.subscription = self.create_subscription(
            Image,
            '/world/xyz_test/model/morphle_xy_axis/link/z_carriage/sensor/microscope_camera/image',
            self.image_callback,
            10
        )

        self.frame_count = 0
        self.start_time = time.time()

    def image_callback(self, msg):

        frame = self.bridge.imgmsg_to_cv2(
            msg,
            desired_encoding='bgr8'
        )

        self.frame_count += 1

        elapsed = time.time() - self.start_time

        if elapsed >= 1.0:
            fps = self.frame_count / elapsed

            self.get_logger().info(
                f'Camera FPS: {fps:.1f}'
            )

            self.frame_count = 0
            self.start_time = time.time()

        cv2.imshow('Morphle Microscope Camera', frame)
        cv2.waitKey(1)


def main(args=None):

    rclpy.init(args=args)

    node = CameraTest()

    try:
        rclpy.spin(node)

    except KeyboardInterrupt:
        pass

    node.destroy_node()
    rclpy.shutdown()

    cv2.destroyAllWindows()


if __name__ == '__main__':
    main()
