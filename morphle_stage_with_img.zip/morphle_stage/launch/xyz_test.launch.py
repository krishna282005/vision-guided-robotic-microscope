import os

from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription, TimerAction
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_directory


def generate_launch_description():

    pkg = get_package_share_directory('morphle_stage')

    world = os.path.join(
        pkg,
        'worlds',
        'xyz_test.world'
    )

    urdf = os.path.join(
        pkg,
        'urdf',
        'xyz_cam',
        'xyz_cam.urdf'
    )

    with open(urdf, 'r') as f:
        robot_description = f.read()

    gazebo = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            '/opt/ros/humble/share/ros_gz_sim/launch/gz_sim.launch.py'
        ),
        launch_arguments={
            'gz_args': world
        }.items()
    )

    robot_state_publisher = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        parameters=[
            {'robot_description': robot_description}
        ]
    )

    spawn = Node(
        package='ros_gz_sim',
        executable='create',
        arguments=[
            '-topic', 'robot_description',
            '-name', 'morphle_xy_axis'
        ],
        output='screen'
    )
    
    joint_state_broadcaster_spawner = Node(
        package='controller_manager',
        executable='spawner',
        arguments=[
            'joint_state_broadcaster',
            '--controller-manager',
            '/controller_manager'
        ],
        output='screen'
    )

    stage_velocity_controller_spawner = Node(
        package='controller_manager',
        executable='spawner',
        arguments=[
            'stage_velocity_controller',
            '--controller-manager',
            '/controller_manager'
        ],
        output='screen'
    )
    
    controller_spawners = TimerAction(
        period=5.0,
        actions=[
            joint_state_broadcaster_spawner,
            stage_velocity_controller_spawner
        ]
    )
    

    return LaunchDescription([
        gazebo,
        robot_state_publisher,
        spawn,
        controller_spawners
    ])
