#!/usr/bin/env python3

import tkinter as tk

import rclpy
from rclpy.node import Node

from sensor_msgs.msg import JointState
from std_msgs.msg import Float64MultiArray


class XYZSliderGUI(Node):

    def __init__(self, root):
        super().__init__('xyz_slider_gui')

        self.root = root

        # Actual joint positions
        self.actual = {
            'x': 0.0,
            'y': 0.0,
            'z': 0.0
        }

        # Target positions
        self.target = {
            'x': 0.0,
            'y': 0.0,
            'z': 0.0
        }

        # Maximum velocity for each axis
        self.max_velocity = 0.10

        # Proportional gain
        self.kp = 2.0

        # Publisher
        self.cmd_pub = self.create_publisher(
            Float64MultiArray,
            '/stage_velocity_controller/commands',
            10
        )

        # Joint state subscriber
        self.joint_sub = self.create_subscription(
            JointState,
            '/joint_states',
            self.joint_state_callback,
            10
        )

        # -------------------------
        # GUI
        # -------------------------

        root.title("XYZ Gantry Debugger")
        root.geometry("520x430")

        title = tk.Label(
            root,
            text="XYZ GANTRY DEBUGGER",
            font=("Arial", 18, "bold")
        )
        title.pack(pady=15)

        self.sliders = {}
        self.target_labels = {}
        self.actual_labels = {}

        self.create_axis("X", -0.25, 0.25)
        self.create_axis("Y", -0.25, 0.25)
        self.create_axis("Z", -0.20, 0.20)

        # Buttons
        button_frame = tk.Frame(root)
        button_frame.pack(pady=20)

        reset_button = tk.Button(
            button_frame,
            text="RESET",
            width=12,
            command=self.reset
        )
        reset_button.pack(side=tk.LEFT, padx=10)

        stop_button = tk.Button(
            button_frame,
            text="STOP",
            width=12,
            command=self.stop
        )
        stop_button.pack(side=tk.LEFT, padx=10)

        # ROS control loop
        self.create_timer(0.02, self.control_loop)

        # Update GUI
        self.update_gui()

    def create_axis(self, axis, minimum, maximum):

        frame = tk.Frame(self.root)
        frame.pack(fill="x", padx=20, pady=5)

        label = tk.Label(
            frame,
            text=f"{axis} Axis",
            width=8,
            font=("Arial", 12, "bold")
        )
        label.pack(side=tk.LEFT)

        slider = tk.Scale(
            frame,
            from_=maximum,
            to=minimum,
            resolution=0.001,
            orient=tk.HORIZONTAL,
            length=300,
            showvalue=False,
            command=lambda value, a=axis.lower():
                self.slider_changed(a, value)
        )

        slider.set(0.0)
        slider.pack(side=tk.LEFT)

        info = tk.Frame(frame)
        info.pack(side=tk.LEFT, padx=10)

        target_label = tk.Label(
            info,
            text="Target: 0.000",
            width=15,
            anchor="w"
        )
        target_label.pack()

        actual_label = tk.Label(
            info,
            text="Actual: 0.000",
            width=15,
            anchor="w"
        )
        actual_label.pack()

        self.sliders[axis.lower()] = slider
        self.target_labels[axis.lower()] = target_label
        self.actual_labels[axis.lower()] = actual_label

    def slider_changed(self, axis, value):

        self.target[axis] = float(value)

    def joint_state_callback(self, msg):

        for i, name in enumerate(msg.name):

            if i >= len(msg.position):
                continue

            if name == 'x_joint':
                self.actual['x'] = msg.position[i]

            elif name == 'y_joint':
                self.actual['y'] = msg.position[i]

            elif name == 'z_joint':
                self.actual['z'] = msg.position[i]

    def control_loop(self):

        command = []

        for axis in ['x', 'y', 'z']:

            error = self.target[axis] - self.actual[axis]

            velocity = self.kp * error

            # Limit velocity
            velocity = max(
                -self.max_velocity,
                min(self.max_velocity, velocity)
            )

            # Stop when close enough
            if abs(error) < 0.001:
                velocity = 0.0

            command.append(velocity)

        msg = Float64MultiArray()
        msg.data = command

        self.cmd_pub.publish(msg)

    def update_gui(self):

        for axis in ['x', 'y', 'z']:

            self.target_labels[axis].config(
                text=f"Target: {self.target[axis]:+.3f} m"
            )

            self.actual_labels[axis].config(
                text=f"Actual: {self.actual[axis]:+.3f} m"
            )

        self.root.after(50, self.update_gui)

    def reset(self):

        for axis in ['x', 'y', 'z']:

            self.target[axis] = 0.0
            self.sliders[axis].set(0.0)

    def stop(self):

        self.target['x'] = self.actual['x']
        self.target['y'] = self.actual['y']
        self.target['z'] = self.actual['z']

        self.sliders['x'].set(self.actual['x'])
        self.sliders['y'].set(self.actual['y'])
        self.sliders['z'].set(self.actual['z'])


def main():

    rclpy.init()

    root = tk.Tk()

    node = XYZSliderGUI(root)

    def ros_spin():

        rclpy.spin_once(node, timeout_sec=0.0)

        root.after(10, ros_spin)

    root.after(10, ros_spin)

    try:
        root.mainloop()

    except KeyboardInterrupt:
        pass

    finally:
        node.stop()

        # Explicit zero command
        msg = Float64MultiArray()
        msg.data = [0.0, 0.0, 0.0]
        node.cmd_pub.publish(msg)

        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
