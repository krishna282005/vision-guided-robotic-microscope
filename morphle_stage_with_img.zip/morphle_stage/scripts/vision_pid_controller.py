#!/usr/bin/env python3

import rclpy
from rclpy.node import Node

from geometry_msgs.msg import Point
from std_msgs.msg import Float64MultiArray


class VisionPIDController(Node):

    def __init__(self):
        super().__init__('vision_pid_controller')

        # ==============================
        # PID GAINS
        # ==============================

        self.kp_x = 0.00009
        self.ki_x = 0.00000
        self.kd_x = 0.000025

        self.kp_y = 0.00009
        self.ki_y = 0.00000
        self.kd_y = 0.000025

        # ==============================
        # LIMITS
        # ==============================

        self.max_velocity = 0.03

        # Stop correcting when close enough
        self.deadband = 5.0

        # Integral limit
        self.max_integral = 100.0

        # ==============================
        # PID STATE
        # ==============================

        self.prev_error_x = 0.0
        self.prev_error_y = 0.0

        self.integral_x = 0.0
        self.integral_y = 0.0

        self.prev_time = self.get_clock().now()

        # ==============================
        # ROS
        # ==============================

        self.error_sub = self.create_subscription(
            Point,
            '/vision/error',
            self.error_callback,
            10
        )

        self.velocity_pub = self.create_publisher(
            Float64MultiArray,
            '/stage_velocity_controller/commands',
            10
        )

        self.get_logger().info('Vision PID Controller started')

    def error_callback(self, msg):

        error_x = msg.x
        error_y = msg.y

        # Time difference
        current_time = self.get_clock().now()

        dt = (
            current_time - self.prev_time
        ).nanoseconds / 1e9

        self.prev_time = current_time

        # Protect against invalid dt
        if dt <= 0.0:
            return

        # ==========================================
        # X AXIS PID
        # ==========================================

        if abs(error_x) < self.deadband:

            self.integral_x = 0.0
            control_x = 0.0

        else:

            # Integral
            self.integral_x += error_x * dt

            # Anti-windup
            self.integral_x = max(
                min(self.integral_x, self.max_integral),
                -self.max_integral
            )

            # Derivative
            derivative_x = (
                error_x - self.prev_error_x
            ) / dt

            control_x = (
                self.kp_x * error_x
                + self.ki_x * self.integral_x
                + self.kd_x * derivative_x
            )

        # ==========================================
        # Y AXIS PID
        # ==========================================

        if abs(error_y) < self.deadband:

            self.integral_y = 0.0
            control_y = 0.0

        else:

            # Integral
            self.integral_y += error_y * dt

            # Anti-windup
            self.integral_y = max(
                min(self.integral_y, self.max_integral),
                -self.max_integral
            )

            # Derivative
            derivative_y = (
                error_y - self.prev_error_y
            ) / dt

            control_y = (
                self.kp_y * error_y
                + self.ki_y * self.integral_y
                + self.kd_y * derivative_y
            )

        # ==========================================
        # SAVE PREVIOUS ERROR
        # ==========================================

        self.prev_error_x = error_x
        self.prev_error_y = error_y

        # ==========================================
        # AXIS SIGN CONVENTION
        # ==========================================

        vx = control_x
        vy = -control_y

        # ==========================================
        # VELOCITY SATURATION
        # ==========================================

        vx = max(
            min(vx, self.max_velocity),
            -self.max_velocity
        )

        vy = max(
            min(vy, self.max_velocity),
            -self.max_velocity
        )

        # ==========================================
        # PUBLISH
        # ==========================================

        command = Float64MultiArray()
        command.data = [vx, vy, 0.0]

        self.velocity_pub.publish(command)


def main(args=None):

    rclpy.init(args=args)

    node = VisionPIDController()

    try:
        rclpy.spin(node)

    except KeyboardInterrupt:
        pass

    # Stop stage
    stop_command = Float64MultiArray()
    stop_command.data = [0.0, 0.0, 0.0]

    node.velocity_pub.publish(stop_command)

    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
