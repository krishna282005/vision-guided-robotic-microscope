#!/usr/bin/env python3

import cv2
import numpy as np

import rclpy
from rclpy.node import Node

from sensor_msgs.msg import Image
from geometry_msgs.msg import Point
from std_msgs.msg import Int32
from std_msgs.msg import Float64MultiArray

from cv_bridge import CvBridge


class VisionGuidedMicroscope(Node):

    def __init__(self):

        super().__init__('vision_guided_microscope')

        self.bridge = CvBridge()

        # =================================================
        # CAMERA
        # =================================================

        self.image_sub = self.create_subscription(
            Image,
            '/world/xyz_test/model/morphle_xy_axis/'
            'link/z_carriage/sensor/microscope_camera/image',
            self.image_callback,
            10
        )

        # =================================================
        # PUBLISHERS
        # =================================================

        # Selected specimen ID
        self.target_id_pub = self.create_publisher(
            Int32,
            '/vision/target_id',
            10
        )

        # Pixel error
        self.error_pub = self.create_publisher(
            Point,
            '/vision/error',
            10
        )

        # Stage velocity
        self.velocity_pub = self.create_publisher(
            Float64MultiArray,
            '/stage_velocity_controller/commands',
            10
        )

        # =================================================
        # TARGET
        # =================================================

        self.selected_id = None

        # =================================================
        # HSV THRESHOLDS
        # =================================================

        # RED
        self.red_lower1 = np.array(
            [0, 80, 80]
        )

        self.red_upper1 = np.array(
            [10, 255, 255]
        )

        self.red_lower2 = np.array(
            [170, 80, 80]
        )

        self.red_upper2 = np.array(
            [180, 255, 255]
        )

        # BLUE
        self.blue_lower = np.array(
            [100, 80, 50]
        )

        self.blue_upper = np.array(
            [140, 255, 255]
        )

        # =================================================
        # MORPHOLOGY
        # =================================================

        self.kernel = np.ones(
            (5, 5),
            np.uint8
        )

        self.min_area = 100.0

        # =================================================
        # PID
        # =================================================

        self.kp_x = 0.00009
        self.ki_x = 0.00000
        self.kd_x = 0.000025

        self.kp_y = 0.00009
        self.ki_y = 0.00000
        self.kd_y = 0.000025

        self.max_velocity = 0.03

        self.deadband = 5.0

        self.max_integral = 100.0

        # PID state
        self.prev_error_x = 0.0
        self.prev_error_y = 0.0

        self.integral_x = 0.0
        self.integral_y = 0.0

        self.prev_time = self.get_clock().now()

        # =================================================
        # GUI
        # =================================================

        self.window_name = 'VISION GUIDED MICROSCOPE'

        cv2.namedWindow(
            self.window_name,
            cv2.WINDOW_NORMAL
        )

        cv2.resizeWindow(
            self.window_name,
            900,
            550
        )

        cv2.setMouseCallback(
            self.window_name,
            self.mouse_callback
        )

        self.get_logger().info(
            'Vision Guided Microscope started'
        )

    # =====================================================
    # RESET PID
    # =====================================================

    def reset_pid(self):

        self.prev_error_x = 0.0
        self.prev_error_y = 0.0

        self.integral_x = 0.0
        self.integral_y = 0.0

        self.prev_time = self.get_clock().now()

    # =====================================================
    # SELECT SPECIMEN
    # =====================================================

    def select_specimen(self, specimen_id):

        self.selected_id = specimen_id

        self.reset_pid()

        msg = Int32()
        msg.data = specimen_id

        self.target_id_pub.publish(msg)

        self.get_logger().info(
            f'Selected specimen {specimen_id}'
        )

    # =====================================================
    # STOP
    # =====================================================

    def stop_stage(self):

        command = Float64MultiArray()

        command.data = [
            0.0,
            0.0,
            0.0
        ]

        self.velocity_pub.publish(
            command
        )

    # =====================================================
    # MOUSE CALLBACK
    # =====================================================

    def mouse_callback(
        self,
        event,
        x,
        y,
        flags,
        param
    ):

        if event != cv2.EVENT_LBUTTONDOWN:
            return

        # -------------------------------------------------
        # GUI layout
        # -------------------------------------------------

        # Camera area:
        # x = 0 ... 640
        #
        # Keypad:
        # x = 660 ... 880

        if x < 650:
            return

        # -------------------------------------------------
        # STOP BUTTON
        # -------------------------------------------------

        if (
            690 <= x <= 850
            and
            450 <= y <= 500
        ):

            self.selected_id = None

            self.reset_pid()

            self.stop_stage()

            self.get_logger().info(
                'STOP pressed'
            )

            return

        # -------------------------------------------------
        # SPECIMEN BUTTONS
        # -------------------------------------------------

        button_width = 70
        button_height = 55

        start_x = 680
        start_y = 100

        gap_x = 25
        gap_y = 20

        columns = 2

        for i in range(20):

            specimen_id = i + 1

            col = i % columns
            row = i // columns

            bx1 = (
                start_x +
                col *
                (button_width + gap_x)
            )

            by1 = (
                start_y +
                row *
                (button_height + gap_y)
            )

            bx2 = bx1 + button_width
            by2 = by1 + button_height

            if (
                bx1 <= x <= bx2
                and
                by1 <= y <= by2
            ):

                self.select_specimen(
                    specimen_id
                )

                break

    # =====================================================
    # IMAGE CALLBACK
    # =====================================================

    def image_callback(self, msg):

        # =================================================
        # ROS IMAGE → OPENCV
        # =================================================

        frame = self.bridge.imgmsg_to_cv2(
            msg,
            desired_encoding='bgr8'
        )

        height, width = frame.shape[:2]

        center_x = width // 2
        center_y = height // 2

        # =================================================
        # HSV
        # =================================================

        hsv = cv2.cvtColor(
            frame,
            cv2.COLOR_BGR2HSV
        )

        # =================================================
        # RED MASK
        # =================================================

        red1 = cv2.inRange(
            hsv,
            self.red_lower1,
            self.red_upper1
        )

        red2 = cv2.inRange(
            hsv,
            self.red_lower2,
            self.red_upper2
        )

        red_mask = cv2.bitwise_or(
            red1,
            red2
        )

        # =================================================
        # BLUE MASK
        # =================================================

        blue_mask = cv2.inRange(
            hsv,
            self.blue_lower,
            self.blue_upper
        )

        # =================================================
        # MORPHOLOGY
        # =================================================

        red_mask = cv2.morphologyEx(
            red_mask,
            cv2.MORPH_OPEN,
            self.kernel
        )

        red_mask = cv2.morphologyEx(
            red_mask,
            cv2.MORPH_CLOSE,
            self.kernel
        )

        blue_mask = cv2.morphologyEx(
            blue_mask,
            cv2.MORPH_OPEN,
            self.kernel
        )

        blue_mask = cv2.morphologyEx(
            blue_mask,
            cv2.MORPH_CLOSE,
            self.kernel
        )

        # =================================================
        # CONTOURS
        # =================================================

        red_contours, _ = cv2.findContours(
            red_mask,
            cv2.RETR_EXTERNAL,
            cv2.CHAIN_APPROX_SIMPLE
        )

        blue_contours, _ = cv2.findContours(
            blue_mask,
            cv2.RETR_EXTERNAL,
            cv2.CHAIN_APPROX_SIMPLE
        )

        # =================================================
        # CELL DATA
        # =================================================

        cells = []

        for contour in red_contours:

            area = cv2.contourArea(
                contour
            )

            if area >= self.min_area:

                moments = cv2.moments(
                    contour
                )

                if moments['m00'] != 0:

                    cx = int(
                        moments['m10'] /
                        moments['m00']
                    )

                    cy = int(
                        moments['m01'] /
                        moments['m00']
                    )

                    cells.append({
                        'type': 'A',
                        'contour': contour,
                        'area': area,
                        'cx': cx,
                        'cy': cy
                    })

        for contour in blue_contours:

            area = cv2.contourArea(
                contour
            )

            if area >= self.min_area:

                moments = cv2.moments(
                    contour
                )

                if moments['m00'] != 0:

                    cx = int(
                        moments['m10'] /
                        moments['m00']
                    )

                    cy = int(
                        moments['m01'] /
                        moments['m00']
                    )

                    cells.append({
                        'type': 'B',
                        'contour': contour,
                        'area': area,
                        'cx': cx,
                        'cy': cy
                    })

        # =================================================
        # SORT CELLS
        # =================================================

        cells.sort(
            key=lambda cell: (
                cell['cy'],
                cell['cx']
            )
        )

        # =================================================
        # SELECTED CELL
        # =================================================

        selected_cell = None

        # =================================================
        # DRAW CELLS
        # =================================================

        for cell_id, cell in enumerate(
            cells,
            start=1
        ):

            contour = cell['contour']
            area = cell['area']
            cx = cell['cx']
            cy = cell['cy']
            cell_type = cell['type']

            # Bounding box
            x, y, w, h = cv2.boundingRect(
                contour
            )

            # ------------------------------------------------
            # Normal contour
            # ------------------------------------------------

            cv2.drawContours(
                frame,
                [contour],
                -1,
                (0, 255, 0),
                2
            )

            # ------------------------------------------------
            # Bounding box
            # ------------------------------------------------

            cv2.rectangle(
                frame,
                (x, y),
                (x + w, y + h),
                (255, 255, 0),
                1
            )

            # ------------------------------------------------
            # Centroid
            # ------------------------------------------------

            cv2.circle(
                frame,
                (cx, cy),
                4,
                (255, 255, 255),
                -1
            )

            # ------------------------------------------------
            # ID
            # ------------------------------------------------

            cv2.putText(
                frame,
                f'{cell_id}:{cell_type}',
                (x, y - 5),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.5,
                (255, 255, 255),
                1
            )

            # ------------------------------------------------
            # SELECTED CELL
            # ------------------------------------------------

            if self.selected_id == cell_id:

                selected_cell = cell

                cv2.rectangle(
                    frame,
                    (x - 5, y - 5),
                    (x + w + 5, y + h + 5),
                    (0, 0, 255),
                    3
                )

                cv2.circle(
                    frame,
                    (cx, cy),
                    8,
                    (0, 0, 255),
                    -1
                )

                cv2.putText(
                    frame,
                    'TARGET',
                    (x, y + h + 20),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.55,
                    (0, 0, 255),
                    2
                )

        # =================================================
        # IMAGE CENTER
        # =================================================

        cv2.drawMarker(
            frame,
            (center_x, center_y),
            (255, 255, 255),
            cv2.MARKER_CROSS,
            20,
            2
        )

        # =================================================
        # PID
        # =================================================

        if selected_cell is not None:

            cx = selected_cell['cx']
            cy = selected_cell['cy']

            error_x = cx - center_x
            error_y = cy - center_y

            # ------------------------------------------------
            # Publish error
            # ------------------------------------------------

            error_msg = Point()

            error_msg.x = float(
                error_x
            )

            error_msg.y = float(
                error_y
            )

            error_msg.z = 0.0

            self.error_pub.publish(
                error_msg
            )

            # ------------------------------------------------
            # Time
            # ------------------------------------------------

            current_time = (
                self.get_clock().now()
            )

            dt = (
                current_time -
                self.prev_time
            ).nanoseconds / 1e9

            self.prev_time = current_time

            if dt > 0.0:

                # =================================================
                # X PID
                # =================================================

                if abs(error_x) < self.deadband:

                    self.integral_x = 0.0
                    control_x = 0.0

                else:

                    self.integral_x += (
                        error_x * dt
                    )

                    self.integral_x = max(
                        min(
                            self.integral_x,
                            self.max_integral
                        ),
                        -self.max_integral
                    )

                    derivative_x = (
                        error_x -
                        self.prev_error_x
                    ) / dt

                    control_x = (
                        self.kp_x * error_x
                        +
                        self.ki_x *
                        self.integral_x
                        +
                        self.kd_x *
                        derivative_x
                    )

                # =================================================
                # Y PID
                # =================================================

                if abs(error_y) < self.deadband:

                    self.integral_y = 0.0
                    control_y = 0.0

                else:

                    self.integral_y += (
                        error_y * dt
                    )

                    self.integral_y = max(
                        min(
                            self.integral_y,
                            self.max_integral
                        ),
                        -self.max_integral
                    )

                    derivative_y = (
                        error_y -
                        self.prev_error_y
                    ) / dt

                    control_y = (
                        self.kp_y * error_y
                        +
                        self.ki_y *
                        self.integral_y
                        +
                        self.kd_y *
                        derivative_y
                    )

                # ------------------------------------------------
                # Save errors
                # ------------------------------------------------

                self.prev_error_x = error_x
                self.prev_error_y = error_y

                # ------------------------------------------------
                # Axis direction
                # ------------------------------------------------

                vx = control_x
                vy = -control_y

                # ------------------------------------------------
                # Saturation
                # ------------------------------------------------

                vx = max(
                    min(
                        vx,
                        self.max_velocity
                    ),
                    -self.max_velocity
                )

                vy = max(
                    min(
                        vy,
                        self.max_velocity
                    ),
                    -self.max_velocity
                )

                # ------------------------------------------------
                # Command stage
                # ------------------------------------------------

                command = Float64MultiArray()

                command.data = [
                    vx,
                    vy,
                    0.0
                ]

                self.velocity_pub.publish(
                    command
                )

            # ------------------------------------------------
            # Draw error line
            # ------------------------------------------------

            cv2.line(
                frame,
                (center_x, center_y),
                (cx, cy),
                (0, 255, 255),
                2
            )

            cv2.putText(
                frame,
                f'TARGET: {self.selected_id}',
                (10, 25),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.65,
                (0, 0, 255),
                2
            )

            cv2.putText(
                frame,
                f'ERROR: ({error_x}, {error_y}) px',
                (10, 50),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.60,
                (0, 255, 255),
                2
            )

        else:

            # No target
            self.stop_stage()

            cv2.putText(
                frame,
                'NO TARGET SELECTED',
                (10, 25),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.65,
                (0, 0, 255),
                2
            )

        # =================================================
        # BUILD GUI
        # =================================================

        gui_width = 900
        gui_height = 550

        gui = np.zeros(
            (gui_height, gui_width, 3),
            dtype=np.uint8
        )

        # -------------------------------------------------
        # Camera image
        # -------------------------------------------------

        gui[
            35:515,
            0:640
        ] = cv2.resize(
            frame,
            (640, 480)
        )

        # -------------------------------------------------
        # Right panel
        # -------------------------------------------------

        cv2.putText(
            gui,
            'SPECIMEN SELECT',
            (665, 45),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.65,
            (255, 255, 255),
            2
        )

        # -------------------------------------------------
        # Buttons
        # -------------------------------------------------

        button_width = 70
        button_height = 55

        start_x = 680
        start_y = 100

        gap_x = 25
        gap_y = 20

        columns = 2

        for i in range(
            min(len(cells), 10)
        ):

            specimen_id = i + 1

            col = i % columns
            row = i // columns

            bx1 = (
                start_x +
                col *
                (button_width + gap_x)
            )

            by1 = (
                start_y +
                row *
                (button_height + gap_y)
            )

            bx2 = bx1 + button_width
            by2 = by1 + button_height

            # Selected button
            if specimen_id == self.selected_id:

                fill = (0, 0, 180)

            else:

                fill = (70, 70, 70)

            cv2.rectangle(
                gui,
                (bx1, by1),
                (bx2, by2),
                fill,
                -1
            )

            cv2.rectangle(
                gui,
                (bx1, by1),
                (bx2, by2),
                (255, 255, 255),
                2
            )

            cv2.putText(
                gui,
                str(specimen_id),
                (
                    bx1 + 25,
                    by1 + 37
                ),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.9,
                (255, 255, 255),
                2
            )

        # -------------------------------------------------
        # STOP
        # -------------------------------------------------

        cv2.rectangle(
            gui,
            (690, 450),
            (850, 500),
            (0, 0, 180),
            -1
        )

        cv2.rectangle(
            gui,
            (690, 450),
            (850, 500),
            (255, 255, 255),
            2
        )

        cv2.putText(
            gui,
            'STOP',
            (735, 485),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.7,
            (255, 255, 255),
            2
        )

        # -------------------------------------------------
        # Cell count
        # -------------------------------------------------

        cv2.putText(
            gui,
            f'Detected: {len(cells)}',
            (665, 525),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.55,
            (255, 255, 255),
            1
        )

        # =================================================
        # SHOW GUI
        # =================================================

        cv2.imshow(
            self.window_name,
            gui
        )

        cv2.waitKey(1)

    # =====================================================
    # SHUTDOWN
    # =====================================================

    def destroy_node(self):

        self.stop_stage()

        cv2.destroyAllWindows()

        super().destroy_node()


def main(args=None):

    rclpy.init(args=args)

    node = VisionGuidedMicroscope()

    try:

        rclpy.spin(node)

    except KeyboardInterrupt:

        pass

    node.destroy_node()

    rclpy.shutdown()


if __name__ == '__main__':

    main()
